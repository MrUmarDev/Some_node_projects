let a = (br, b) => {
  let soz = '';
  let harf = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
  for (let i = 0; i < br.length; i++) {
    let el = br[i];
    let ks = harf.indexOf(el);
    if (ks !== -1) {
      let ys = (ks + b) % harf.length;
      soz += harf[ys >= 0 ? ys : harf.length + ys];
    } else {
      soz += el;
    }
  }
  return soz;
}

let chqar = "Umar Mirsaidov 20 yosh";
let son = 3;

console.log(a(chqar, son));
