function randRang() {
  var rangSon = '0123456789ABCDEF';
  var rang = '#';
  for (var i = 0; i < 6; i++) {
    rang += rangSon[Math.floor(Math.random() * 16)];
  }
  return rang;
}

function orqaFon() {
  var randomRang = randRang();
  document.body.style.backgroundColor = randomRang;
  document.getElementById("colorDisplayButton").style.backgroundColor = randomRang;
  document.getElementById("colorDisplayButton").innerHTML = "Rang: " + randomRang;
}
