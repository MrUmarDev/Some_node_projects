function kurring(kSonla) {
  return function(kolbak) {
    let umum = 0;
    for (let i = 0; i < kSonla.length; i++) {
      umum += kSonla[i];
    }
    kolbak(umum);
  }
}

const kSonla = [1, 56, 99, 25, 80, 77];
const kolbak2 = kurring(kSonla);
kolbak2(function(umum) {
  console.log(umum);
});
