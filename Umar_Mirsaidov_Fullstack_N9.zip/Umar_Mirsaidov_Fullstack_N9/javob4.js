String.prototype.yaratMap = function(kollbak) {
  let jav = '';

  for (let i = 0; i < this.length; i++) {
    jav += kollbak(this.charAt(i));
  }

  return jav;
};


const krSoz = 'Umar Mirsaidov. Fullstack N9';

const javob = krSoz.yaratMap((harf) => {
  return harf.toUpperCase();
});

console.log(javob);
