function ekub(a, b) {
  a = Math.abs(a);
  b = Math.abs(b);

  if (b === 0) {
    return a;
  }

  return ekub(b, a % b);
}

let son1 = 12;
let son2 = 18;
let javob = ekub(son1, son2);
console.log(javob);
